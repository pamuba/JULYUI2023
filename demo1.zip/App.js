import { StatusBar } from 'expo-status-bar';
import { FlatList, StyleSheet, TouchableWithoutFeedback, View, Alert, Keyboard } from 'react-native';
import { useState } from 'react';
import Header from './components/header';
import TodoItem from './components/todoItem';
import AddTodo from './components/addTodo';
import { set } from 'mongoose';

export default function App() {
  
  const [todos, setTodos] = useState([
    {text:"Implement React", key:'1'},
    {text:"Buy Coffee", key:'2'},
    {text:"Play with the Switch", key:'3'}
  ]);

  const pressHandler = (key) => {
    setTodos((prevTodo) => {
      return prevTodo.filter(item => item.key !== key);
    });
  }

  const submitHandler = (text) => {
    if(text.length > 3){
      console.log("Inside")
      setTodos((prevTodos) => {
        return[
          {text:text, key: Math.random().toString()},
          ...prevTodos
        ]
      })
    }else{
      Alert.alert('ERROR','Todos must be atlest 4 chars long', [
        {text:'understood', onPress:()=>console.log('alert closed')}
      ])
    }
  }
  return (
    <TouchableWithoutFeedback onPress={()=> {
      Keyboard.dismiss();
      console.log("dismissed keyboard")
    }}>
      <View style={styles.container}>
      <Header />
        <View style={styles.content}>
          <AddTodo submitHandler={submitHandler}/>
          <View style={styles.list}>
             <FlatList
              data = {todos}
              renderItem={({item}) => (
                // <Text>{item.text}</Text>
                <TodoItem item={item} pressHandler={pressHandler}/>
              )}
              />
            </View>
        </View>
    </View>
    </TouchableWithoutFeedback>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    // alignItems: 'center',
    // justifyContent: 'center',
  },
  content:{
    padding:40
  },
  list:{
    marginTop:25,
  }
});

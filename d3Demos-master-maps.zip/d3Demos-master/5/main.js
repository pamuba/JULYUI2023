var svg = d3.select('#chart-area').append("svg")
                        .attr('height', 400)
                        .attr('width', 400);


const express = require('express')
const path = require('path')
require('dotenv').config()
const api = require('./server/routes/api')


const port = process.env.PORT || 3000 
//entire express app
const app = express()
//body-parser
app.use(express.json())
app.use(express.static(path.join(__dirname, 'dist/browser/')))

//localhost:9000/api
app.use('/api', api);

app.get("/{*any}", (req, res)=>{
    res.sendFile(path.join(__dirname, 'dist/browser/index.html'))
})



app.listen(port, function(){
    console.log("Server running at:"+port)
})
const express = require('express')
const router = express.Router()
const mongoose = require('mongoose')
// const Video = require('../models/video')

//.env .confg
const db = process.env.dbstring

// mongoose.connect(db)
// .then((err)=>{
//     if(err){console.log('Error!:'+err)}
//     else{console.log("Connected to MongoDB")}
// })

//localhost:9000/api
router.get('/', function(req, res){
    res.send("Heloo from API");
})

module.exports = router 
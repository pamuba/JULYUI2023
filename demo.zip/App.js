import { StatusBar } from 'expo-status-bar';
import { FlatList, StyleSheet, Text, View, TouchableOpacity, TextInput, ScrollView } from 'react-native';
import { useState } from 'react';
import Header from './components/header';
import TodoItem from './components/todoItem';
import AddTodo from './components/addTodo';

export default function App() {
  
  const [todos, setTodos] = useState([
    {text:"Implement React", key:'1'},
    {text:"Buy Coffee", key:'2'},
    {text:"Play with the Switch", key:'3'}
  ]);

  const pressHandler = (key) => {
    setTodos((prevTodo) => {
      return prevTodo.filter(item => item.key !== key);
    });
  }

  const submitHandler = (text) => {
    
  }
  return (
    <View style={styles.container}>
      <Header />
        <View style={styles.content}>
          <AddTodo/>
          <View style={styles.list}>
             <FlatList
              data = {todos}
              renderItem={({item}) => (
                // <Text>{item.text}</Text>
                <TodoItem item={item} pressHandler={pressHandler}/>
              )}
              />
            </View>
        </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    // alignItems: 'center',
    // justifyContent: 'center',
  },
  content:{
    padding:40
  },
  list:{
    marginTop:25,
  }
});
